"""
MAUDE Client Tools - Local file operations and server communication.
"""

import os
import subprocess
import json
from pathlib import Path
from typing import Optional
from config import SERVER_SSH_HOST, SERVER_WORK_DIR, LOCAL_TRANSFER_DIR, LOCAL_SHARED_DIR, SERVER_SHARED_DIR, FILE_SERVER_URL
import requests as _requests

# Ensure transfer directory exists
TRANSFER_DIR = Path(LOCAL_TRANSFER_DIR).expanduser()
TRANSFER_DIR.mkdir(parents=True, exist_ok=True)

# Ensure shared directory exists
SHARED_DIR = Path(LOCAL_SHARED_DIR).expanduser()
SHARED_DIR.mkdir(parents=True, exist_ok=True)

# Tool definitions for the LLM
TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read a local file. Returns content with line numbers.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file"},
                    "start_line": {"type": "integer", "description": "Starting line (1-indexed, optional)"},
                    "end_line": {"type": "integer", "description": "Ending line (optional)"}
                },
                "required": ["path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Write content to a local file. Creates directories if needed.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file"},
                    "content": {"type": "string", "description": "Content to write"}
                },
                "required": ["path", "content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "edit_file",
            "description": "Replace lines in a local file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to the file"},
                    "start_line": {"type": "integer", "description": "First line to replace (1-indexed)"},
                    "end_line": {"type": "integer", "description": "Last line to replace"},
                    "new_content": {"type": "string", "description": "Replacement content"}
                },
                "required": ["path", "start_line", "end_line", "new_content"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_directory",
            "description": "List contents of a local directory.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Directory path (default: current directory)"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "search_files",
            "description": "Search for text in local files.",
            "parameters": {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Text or regex to search for"},
                    "path": {"type": "string", "description": "Directory to search (default: current)"},
                    "file_pattern": {"type": "string", "description": "File glob pattern (e.g., '*.py')"}
                },
                "required": ["pattern"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Run a shell command locally.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Command to execute"}
                },
                "required": ["command"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "upload_to_server",
            "description": "Upload/push a local file to the Spark server. Use when user says 'upload', 'push', or 'send to server'.",
            "parameters": {
                "type": "object",
                "properties": {
                    "local_path": {"type": "string", "description": "Local file path"},
                    "remote_path": {"type": "string", "description": "Destination path on server (relative to work dir)"}
                },
                "required": ["local_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "download_from_server",
            "description": "Download/pull a file from the Spark server. Use when user says 'pull', 'download', 'grab', or 'fetch from server'.",
            "parameters": {
                "type": "object",
                "properties": {
                    "remote_path": {"type": "string", "description": "File path on server"},
                    "local_path": {"type": "string", "description": "Local destination (default: transfers folder)"}
                },
                "required": ["remote_path"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_server_files",
            "description": "List files in a directory on the Spark server. Use to find files before pulling/downloading.",
            "parameters": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Directory path on server (default: work dir)"}
                },
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "run_server_command",
            "description": "Run a command on the Spark server via SSH.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Command to execute on server"}
                },
                "required": ["command"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "send_to_server_maude",
            "description": "Send a message to the MAUDE instance running on the server.",
            "parameters": {
                "type": "object",
                "properties": {
                    "message": {"type": "string", "description": "Message to send to server MAUDE"}
                },
                "required": ["message"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "list_shared",
            "description": "List files in the shared folder (auto-synced between client and server). Check here first when looking for files from the server.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "sync_shared",
            "description": "Trigger an immediate sync of the shared folder between client and server.",
            "parameters": {
                "type": "object",
                "properties": {},
                "required": []
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "pull_shared",
            "description": "Pull/download a specific file from the server's shared folder. Use when user says 'pull', 'grab', or 'download' a file.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filename": {"type": "string", "description": "Name of the file in the server's shared folder"},
                    "local_path": {"type": "string", "description": "Local destination path (defaults to ~/.maude/shared/)"}
                },
                "required": ["filename"]
            }
        }
    }
]


def execute_tool(name: str, arguments: dict) -> str:
    """Execute a tool and return the result."""
    try:
        if name == "read_file":
            return read_file(
                arguments["path"],
                arguments.get("start_line"),
                arguments.get("end_line")
            )
        elif name == "write_file":
            return write_file(arguments["path"], arguments["content"])
        elif name == "edit_file":
            return edit_file(
                arguments["path"],
                arguments["start_line"],
                arguments["end_line"],
                arguments["new_content"]
            )
        elif name == "list_directory":
            return list_directory(arguments.get("path", "."))
        elif name == "search_files":
            return search_files(
                arguments["pattern"],
                arguments.get("path", "."),
                arguments.get("file_pattern")
            )
        elif name == "run_command":
            return run_command(arguments["command"])
        elif name == "upload_to_server":
            return upload_to_server(
                arguments["local_path"],
                arguments.get("remote_path")
            )
        elif name == "download_from_server":
            return download_from_server(
                arguments["remote_path"],
                arguments.get("local_path")
            )
        elif name == "list_server_files":
            return list_server_files(arguments.get("path"))
        elif name == "run_server_command":
            return run_server_command(arguments["command"])
        elif name == "send_to_server_maude":
            return send_to_server_maude(arguments["message"])
        elif name == "list_shared":
            return list_shared()
        elif name == "sync_shared":
            return sync_shared()
        elif name == "pull_shared":
            return pull_shared(
                arguments.get("filename", ""),
                arguments.get("local_path")
            )
        else:
            return f"Unknown tool: {name}"
    except Exception as e:
        return f"Error: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Local File Operations
# ─────────────────────────────────────────────────────────────────────────────

def read_file(path: str, start_line: int = None, end_line: int = None) -> str:
    """Read a local file with optional line range."""
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return f"Error: File not found: {path}"

    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as f:
            lines = f.readlines()

        # Apply line range
        if start_line is not None:
            start_idx = max(0, start_line - 1)
            end_idx = end_line if end_line else len(lines)
            lines = lines[start_idx:end_idx]
            line_offset = start_idx
        else:
            line_offset = 0

        # Format with line numbers
        numbered = []
        for i, line in enumerate(lines):
            line_num = i + line_offset + 1
            numbered.append(f"{line_num:4d} | {line.rstrip()}")

        return "\n".join(numbered)
    except Exception as e:
        return f"Error reading file: {e}"


def write_file(path: str, content: str) -> str:
    """Write content to a local file."""
    path = os.path.expanduser(path)
    try:
        os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        return f"Successfully wrote {len(content)} bytes to {path}"
    except Exception as e:
        return f"Error writing file: {e}"


def edit_file(path: str, start_line: int, end_line: int, new_content: str) -> str:
    """Replace lines in a file."""
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return f"Error: File not found: {path}"

    try:
        with open(path, 'r', encoding='utf-8') as f:
            lines = f.readlines()

        # Replace lines
        new_lines = new_content.split('\n')
        if not new_content.endswith('\n'):
            new_lines = [line + '\n' for line in new_lines]
        else:
            new_lines = [line + '\n' for line in new_lines[:-1]] + ['']

        lines[start_line-1:end_line] = new_lines

        with open(path, 'w', encoding='utf-8') as f:
            f.writelines(lines)

        return f"Successfully edited lines {start_line}-{end_line} in {path}"
    except Exception as e:
        return f"Error editing file: {e}"


def list_directory(path: str = ".") -> str:
    """List directory contents."""
    path = os.path.expanduser(path)
    if not os.path.exists(path):
        return f"Error: Directory not found: {path}"

    try:
        entries = []
        for entry in sorted(os.listdir(path)):
            full_path = os.path.join(path, entry)
            if os.path.isdir(full_path):
                entries.append(f"[DIR]  {entry}/")
            else:
                size = os.path.getsize(full_path)
                entries.append(f"[FILE] {entry} ({size} bytes)")

        return f"Contents of {path}:\n" + "\n".join(entries)
    except Exception as e:
        return f"Error listing directory: {e}"


def search_files(pattern: str, path: str = ".", file_pattern: str = None) -> str:
    """Search for text in files."""
    path = os.path.expanduser(path)

    cmd = ["grep", "-rn", pattern, path]
    if file_pattern:
        cmd = ["grep", "-rn", "--include", file_pattern, pattern, path]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        output = result.stdout.strip()
        if not output:
            return f"No matches found for '{pattern}'"

        # Limit output
        lines = output.split('\n')
        if len(lines) > 50:
            output = '\n'.join(lines[:50]) + f"\n... and {len(lines)-50} more matches"

        return output
    except subprocess.TimeoutExpired:
        return "Error: Search timed out"
    except Exception as e:
        return f"Error searching: {e}"


def run_command(command: str) -> str:
    """Run a local shell command."""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=60,
            cwd=os.getcwd()
        )

        output = result.stdout
        if result.stderr:
            output += f"\n[stderr]: {result.stderr}"
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"

        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out after 60 seconds"
    except Exception as e:
        return f"Error running command: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Server Communication
# ─────────────────────────────────────────────────────────────────────────────

def upload_to_server(local_path: str, remote_path: str = None) -> str:
    """Upload a file to the Spark server via HTTP file server."""
    local_path = os.path.expanduser(local_path)
    if not os.path.exists(local_path):
        return f"Error: Local file not found: {local_path}"

    filename = os.path.basename(local_path)

    try:
        with open(local_path, "rb") as f:
            data = f.read()
        r = _requests.post(f"{FILE_SERVER_URL}/upload/{filename}", data=data, timeout=120)
        if r.status_code == 200:
            return f"Uploaded '{filename}' to server transfers folder ({len(data):,} bytes)"
        else:
            return f"Error uploading: {r.json().get('error', r.text)}"
    except _requests.ConnectionError:
        return "Error: Can't reach file server. Make sure Tailscale is connected and the server is running."
    except Exception as e:
        return f"Error: {e}"


def download_from_server(remote_path: str, local_path: str = None) -> str:
    """Download a file from the server's shared folder via HTTP."""
    filename = os.path.basename(remote_path)
    return pull_shared(filename, local_path)


def list_server_files(path: str = None) -> str:
    """List files on the server's shared folder."""
    return list_shared()


def run_server_command(command: str) -> str:
    """Run a command on the server via SSH."""
    try:
        result = subprocess.run(
            ["ssh", SERVER_SSH_HOST, f"cd {SERVER_WORK_DIR} && {command}"],
            capture_output=True,
            text=True,
            timeout=60
        )

        output = result.stdout
        if result.stderr:
            output += f"\n[stderr]: {result.stderr}"
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"

        return output.strip() or "(no output)"
    except subprocess.TimeoutExpired:
        return "Error: Command timed out"
    except Exception as e:
        return f"Error: {e}"


def send_to_server_maude(message: str) -> str:
    """Send a message to the server MAUDE instance via tmux."""
    try:
        # Sanitize message - keep only safe characters
        safe_msg = ''.join(c for c in message if c.isalnum() or c in ' .,!?-_:@')

        if not safe_msg.strip():
            return "Error: Message was empty after sanitization"

        # Send to MAUDE tmux session on server
        result = subprocess.run(
            ["ssh", SERVER_SSH_HOST, f'tmux send-keys -t maude "{safe_msg}" Enter'],
            capture_output=True,
            text=True,
            timeout=10
        )

        if result.returncode == 0:
            return f"Message sent to server MAUDE: {safe_msg[:100]}..."
        else:
            return f"Error sending to server MAUDE: {result.stderr}"
    except Exception as e:
        return f"Error: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Shared Folder Operations
# ─────────────────────────────────────────────────────────────────────────────

def list_shared() -> str:
    """List files in the server's shared folder via HTTP file server."""
    try:
        r = _requests.get(f"{FILE_SERVER_URL}/list", timeout=5)
        data = r.json()
        if "error" in data:
            return f"Error: {data['error']}"
        files = data.get("files", [])
        if not files:
            return "Shared folder on server is empty."
        entries = []
        for f in files:
            if f["is_dir"]:
                entries.append(f"  [DIR]  {f['name']}/")
            else:
                size = f["size"]
                entries.append(f"  [FILE] {f['name']} ({size:,} bytes)")
        return "Server shared folder:\n" + "\n".join(entries)
    except _requests.ConnectionError:
        return "Error: Can't reach file server. Make sure Tailscale is connected and the server is running."
    except Exception as e:
        return f"Error: {e}"


def pull_shared(filename: str, local_path: str = None) -> str:
    """Pull a file from the server's shared folder via HTTP."""
    dest_dir = Path(LOCAL_SHARED_DIR).expanduser()
    dest_dir.mkdir(parents=True, exist_ok=True)

    if local_path:
        dest = Path(os.path.expanduser(local_path))
    else:
        dest = dest_dir / filename

    try:
        r = _requests.get(f"{FILE_SERVER_URL}/download/{filename}", timeout=120, stream=True)
        if r.status_code == 404:
            return f"Error: '{filename}' not found on server. Use list_shared to see available files."
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192):
                f.write(chunk)
        size = dest.stat().st_size
        return f"Pulled '{filename}' to {dest} ({size:,} bytes)"
    except _requests.ConnectionError:
        return "Error: Can't reach file server. Make sure Tailscale is connected and the server is running."
    except Exception as e:
        return f"Error: {e}"


def sync_shared() -> str:
    """Pull all files from server shared folder."""
    try:
        r = _requests.get(f"{FILE_SERVER_URL}/list", timeout=5)
        data = r.json()
        files = data.get("files", [])
        if not files:
            return "Nothing to sync — server shared folder is empty."
        pulled = []
        for f in files:
            if not f["is_dir"]:
                result = pull_shared(f["name"])
                pulled.append(result)
        return "Sync complete:\n" + "\n".join(pulled)
    except _requests.ConnectionError:
        return "Error: Can't reach file server. Make sure Tailscale is connected and the server is running."
    except Exception as e:
        return f"Error: {e}"


# ─────────────────────────────────────────────────────────────────────────────
# Dynamic Tool Filtering and Fast Dispatch
# ─────────────────────────────────────────────────────────────────────────────

import re as _re

# Core tools always sent
_CORE_TOOL_NAMES = {
    "read_file", "write_file", "list_directory", "run_command",
    "search_files", "edit_file", "list_shared", "sync_shared", "pull_shared",
}

# Server tools activated by keyword
_SERVER_TOOL_NAMES = {
    "upload_to_server", "download_from_server", "list_server_files",
    "run_server_command", "send_to_server_maude",
}

_SERVER_KEYWORDS = [
    "server", "spark", "upload", "download", "remote", "ssh", "server maude",
    "pull", "push", "fetch", "grab", "send to server", "get from server",
    "shared folder", "shared", "transfer", "sync",
    # Services only available on server — trigger send_to_server_maude
    "gmail", "email", "inbox", "drive", "google doc", "sheets", "spreadsheet",
    "calendar", "event", "slides", "presentation", "contacts", "youtube",
    "substack", "browser", "tweet", "bluesky", "linkedin", "social media",
]

# Build lookup
_TOOL_BY_NAME = {t["function"]["name"]: t for t in TOOLS}

def get_tools_for_message(message: str) -> list:
    """Return filtered tools relevant to the user's message."""
    msg_lower = message.lower()
    active = set(_CORE_TOOL_NAMES)

    for kw in _SERVER_KEYWORDS:
        if kw in msg_lower:
            active.update(_SERVER_TOOL_NAMES)
            break

    return [t for t in TOOLS if t["function"]["name"] in active]

# Fast dispatch patterns
def _extract_filename(match, msg):
    """Extract filename from a pull/grab/fetch command."""
    # Get everything after the keyword as the filename
    keyword_end = match.end()
    filename = msg[keyword_end:].strip().strip('"').strip("'")
    if filename:
        return {"filename": filename}
    return None

_FAST_PATTERNS = [
    (_re.compile(r'\b(?:pull|grab|fetch)\s+(.+)', _re.I),
     "pull_shared", lambda m, msg: {"filename": m.group(1).strip().strip('"').strip("'")}),
    (_re.compile(r'\b(?:list|show|what.?s in)\b.*\b(?:shared)\b', _re.I),
     "list_shared", lambda m, msg: {}),
    (_re.compile(r'\b(?:list|show|what.?s in)\b.*\b(?:director|folder|files)\b', _re.I),
     "list_directory", lambda m, msg: {"path": "."}),
    (_re.compile(r'\b(?:list|show)\b.*\bserver\b.*\b(?:files|director)\b', _re.I),
     "list_server_files", lambda m, msg: {"path": ""}),
    (_re.compile(r'\b(?:upload|send)\b.*\b(?:to server|to spark)\b', _re.I),
     None, None),  # Skip — needs path from user
    (_re.compile(r'\b(?:download|get)\b.*\b(?:from server|from spark)\b', _re.I),
     None, None),  # Skip — needs path from user
]

def fast_dispatch(message: str):
    """Try to match message to a direct tool call. Returns (name, args, result) or None."""
    msg = message.strip()
    for pattern, tool_name, arg_builder in _FAST_PATTERNS:
        if tool_name is None:
            continue
        match = pattern.search(msg)
        if match:
            try:
                args = arg_builder(match, msg)
                result = execute_tool(tool_name, args)
                if result and not result.startswith("Error:"):
                    return tool_name, args, result
            except Exception:
                continue
    return None
