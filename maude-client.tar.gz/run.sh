#!/bin/bash
cd "$(dirname "$0")"
./venv/bin/python chat_local.py
